package org.apache.ranger.services.atlas.test;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.NewCookie;

import org.codehaus.jettison.json.JSONException;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.api.client.filter.LoggingFilter;
import com.sun.jersey.api.json.JSONConfiguration;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class TestAtlasClient {
	@SuppressWarnings("unused")
	private static final String EXPECTED_MIME_TYPE = "application/json";

	public static void main(String[] argc) throws JSONException {
	
		
		ClientConfig clientConfig = new DefaultClientConfig();
		  clientConfig.getFeatures().put( JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);

          Client client = Client.create(clientConfig);
          final HTTPBasicAuthFilter authFilter = new HTTPBasicAuthFilter("admin", "admin");
          client.addFilter(authFilter);
         /* client.addFilter(new LoggingFilter());*/
          WebResource webResource = client
                  .resource("http://10.43.182.242:21000/api/atlas/types");

            ClientResponse response2 = webResource.accept("application/json")
              .type("application/json").put(ClientResponse.class);
          	
		System.out.println(response2.getEntity(String.class).toString()+"*******");
	   
	}

}
